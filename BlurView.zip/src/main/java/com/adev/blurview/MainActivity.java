package com.adev.blurview;

import android.graphics.drawable.Drawable;
import android.view.ViewGroup;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import eightbitlab.com.blurview.BlurView;
import android.os.Bundle;
import eightbitlab.com.blurview.RenderScriptBlur;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		BlurView blurView = findViewById(R.id.blurView);
		SeekBar sb = findViewById(R.id.sb);
		TextView sbt = findViewById(R.id.sbt);
		View decorView = getWindow().getDecorView();
    	ViewGroup rootView = (ViewGroup) decorView.findViewById(android.R.id.content);
    	Drawable windowBackground = decorView.getBackground();
		blurView.setupWith(rootView, new RenderScriptBlur(MainActivity.this))
         	   .setFrameClearDrawable(windowBackground)
                .setBlurRadius(1f);
		sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){
			@Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            	float f = progress/100.0f;
                sbt.setText("Value " + f);
				if (f > 0){
					blurView.setBlurRadius(f*25);
				} else {
					blurView.setBlurRadius(1f);
				}
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
             
            }
		});
    }
}